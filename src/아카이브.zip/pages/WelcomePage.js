import React from 'react';
import LoginForm from '../components/auth/LoginForm';

const WelcomePage = () => {
  return <LoginForm />;
};

export default WelcomePage;
